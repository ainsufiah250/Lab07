
document.addEventListener("DOMContentLoaded", function () {
    const collapsibleButton = document.querySelector(".collapsible");
    const content = document.querySelector(".content");

    collapsibleButton.addEventListener("click", function () {
        
        content.classList.toggle("active");
    });
});