document.addEventListener("DOMContentLoaded", function () {
  
    let slideIndex = 0;
    showSlides();

    function showSlides() {
        let i;
        let slides = document.getElementsByClassName("mySlides");
        for (i = 0; i < slides.length; i++) {
            slides[i].style.display = "none";
        }
        slideIndex++;
        if (slideIndex > slides.length) {
            slideIndex = 1;
        }
        slides[slideIndex - 1].style.display = "block";
        setTimeout(showSlides, 4000); 
    }

   
    function animateProgressBars() {
        const progressBars = document.querySelectorAll('.progress-bar');
        progressBars.forEach(bar => {
            const targetProgress = bar.getAttribute('data-progress');
        
            bar.style.width = targetProgress + '%';
        });
    }

    
    const skillsSection = document.getElementById('skills-section');
    if (skillsSection) {
        const observer = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateProgressBars();
                    
                    observer.unobserve(entry.target); 
                }
            });
        }, { threshold: 0.5 }); 
        observer.observe(skillsSection);
    }
    
    
    const collapsibles = document.querySelectorAll(".collapsible");

    collapsibles.forEach(button => {
        button.addEventListener("click", function () {
            this.classList.toggle("active-collapsible");
            const content = this.nextElementSibling;
            
            
            content.classList.toggle("show");
        });
    });

   
    document.querySelectorAll('#side-nav a').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            document.querySelector(targetId).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});